"""Existing 4096-token prefill probe with response and repeatability gates."""
import json
from pathlib import Path
import statistics
import sys
import time
import urllib.request

port, out = int(sys.argv[1]), Path(sys.argv[2])
model = 'qwen3.6-35b-a3b-w8a8'
base = f'http://127.0.0.1:{port}'
out.mkdir(parents=True, exist_ok=True)


def request(endpoint, payload):
    req = urllib.request.Request(base + endpoint, data=json.dumps(payload).encode(),
                                 headers={'Content-Type': 'application/json'})
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=180) as r:
        result = json.loads(r.read())
    assert result.get('choices') and result.get('usage'), result
    return (time.perf_counter() - t0) * 1000, result


def completion(seed, count):
    ids = [((seed * 7919 + i * 31) % 90000) + 1000 for i in range(4096)]
    ms, result = request('/v1/completions', dict(model=model, prompt=ids, max_tokens=count,
                                               temperature=0.0, stream=False, ignore_eos=True))
    assert result['usage']['prompt_tokens'] == 4096
    assert result['usage']['completion_tokens'] == count
    return ms, result


with urllib.request.urlopen(base + '/health', timeout=10) as r:
    assert r.status == 200

_, short = request('/v1/chat/completions', dict(
    model=model, messages=[{'role': 'user', 'content': 'Reply with exactly the number 42.'}],
    max_tokens=32, temperature=0.0, chat_template_kwargs={'enable_thinking': False}))
(out / 'short_response.json').write_text(json.dumps(short, indent=2))
text = short['choices'][0]['message']['content']
assert text is not None and '42' in text, ('SHORT_REQUEST_INCORRECT', short)

stable = []
for _ in range(3):
    stable.append(completion(777, 32)[1])
    (out / 'correctness.json').write_text(json.dumps({'short': short, 'long_repeats': stable}, indent=2))
texts = [r['choices'][0]['text'] for r in stable]
assert len(set(texts)) == 1, 'LONG_PREFILL_OUTPUT_UNSTABLE'
out.mkdir(parents=True, exist_ok=True)
(out / 'correctness.json').write_text(json.dumps({'short': short, 'long_repeats': stable}, indent=2))
print('SERVICE_CORRECTNESS_AND_STABILITY_PASS', flush=True)

# A second token length distinguishes an initial-shape effect from stable decoding.
responses_2k = []
ids_2k = [((777 * 7919 + i * 31) % 90000) + 1000 for i in range(2048)]
for _ in range(3):
    _, result = request('/v1/completions', dict(model=model, prompt=ids_2k, max_tokens=32,
                                              temperature=0.0, stream=False, ignore_eos=True, logprobs=2))
    responses_2k.append(result)
    (out / 'stability_2k.json').write_text(json.dumps(responses_2k, indent=2))
assert len({x['choices'][0]['text'] for x in responses_2k}) == 1, 'TWO_K_OUTPUT_UNSTABLE'
probabilities = [x['choices'][0]['logprobs']['top_logprobs'] for x in responses_2k]
print('TWO_K_TEXT_STABILITY_PASS', flush=True)
print('TWO_K_TOP_LOGPROBS_IDENTICAL', all(x == probabilities[0] for x in probabilities), flush=True)
print('DIAGNOSTIC_ONLY_NO_PERFORMANCE', flush=True)
