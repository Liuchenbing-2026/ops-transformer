"""Existing 4096-token prefill probe with response and repeatability gates."""
import json
from pathlib import Path
import statistics
import sys
import time
import urllib.request

port, out = int(sys.argv[1]), Path(sys.argv[2])
model = 'qwen3.6-35b-a3b-w8a8'
base = f'http://127.0.0.1:{port}'


def request(endpoint, payload):
    req = urllib.request.Request(base + endpoint, data=json.dumps(payload).encode(),
                                 headers={'Content-Type': 'application/json'})
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=180) as r:
        result = json.loads(r.read())
    assert result.get('choices') and result.get('usage'), result
    return (time.perf_counter() - t0) * 1000, result


def completion(seed, count):
    ids = [((seed * 7919 + i * 31) % 90000) + 1000 for i in range(4096)]
    ms, result = request('/v1/completions', dict(model=model, prompt=ids, max_tokens=count,
                                               temperature=0.0, stream=False, ignore_eos=True))
    assert result['usage']['prompt_tokens'] == 4096
    assert result['usage']['completion_tokens'] == count
    return ms, result


out.mkdir(parents=True, exist_ok=True)
preflight = out / '.write_preflight'
with preflight.open('xb') as f:
    f.write(b'output path writable\n')
preflight.unlink()

for i in range(4):
    completion(900 + i, 1)
samples = []
for i in range(12):
    ms, result = completion(1000 + i, 1)
    samples.append({'seed': 1000 + i, 'ms': ms, 'response': result})
    print(f'PREFILL_REQUEST {i} {ms:.3f} ms', flush=True)
times = sorted(s['ms'] for s in samples)
summary = dict(n=len(times), min_ms=min(times), median_ms=statistics.median(times),
               trimmed_mean_ms=statistics.mean(times[1:-1]), max_ms=max(times))
(out / 'probe_results.json').write_text(json.dumps({'summary': summary, 'samples': samples}, indent=2))
print('PROBE_SUMMARY ' + json.dumps(summary), flush=True)
