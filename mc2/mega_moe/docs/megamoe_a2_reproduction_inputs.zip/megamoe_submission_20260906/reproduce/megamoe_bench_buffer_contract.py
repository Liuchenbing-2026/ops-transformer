"""Correctness-gated adaptation of the existing megamoe_bench.py harness.

Usage: torchrun ... megamoe_bench_verified.py CONFIGS_JSON MODE OUTPUT_DIR REF_DIR
MODE is record, compare, or perf. No device timing is accepted before correctness.
"""
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time
from datetime import timedelta

import torch
import torch.distributed as dist
import torch_npu
from cann_ops_transformer.ops.mega_moe import get_symm_buffer_for_mega_moe, mega_moe

HIDDEN, INTER, TOPK = 2048, 512, 8


def fingerprint(tensors):
    h = hashlib.sha256()
    for t in tensors:
        h.update(str((tuple(t.shape), t.dtype)).encode())
        h.update(t.contiguous().view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def make_case(cfg, rank, world, dev):
    torch.manual_seed(int(cfg.get('seed', 1024)) + rank)
    experts = int(cfg.get('experts', world * 32))
    assert experts % world == 0 and experts >= TOPK
    e = experts // world
    tokens, dummy = int(cfg['tokens']), int(cfg.get('dummy', 4))
    rows = tokens + dummy
    w13 = torch.randint(-8, 8, (e, HIDDEN, 2 * INTER), dtype=torch.int8)
    w2 = torch.randint(-8, 8, (e, INTER, HIDDEN), dtype=torch.int8)
    # Same packing as vllm-ascend scale_from_float_to_int64, with valid scales.
    s13 = torch.linspace(0.005, 0.025, e * 2 * INTER).reshape(e, -1)
    s2 = torch.linspace(0.005, 0.025, e * HIDDEN).reshape(e, -1)
    x = torch.randn(rows, HIDDEN, dtype=torch.bfloat16)
    routes = torch.rand(rows, experts)
    if cfg.get('routing') == 'skew':
        routes[:, :e] += 2  # All ranks target rank 0: long messages and empty peers.
    ids = routes.topk(TOPK, dim=-1).indices.to(torch.int32)
    probs = torch.rand(rows, TOPK)
    probs /= probs.sum(dim=-1, keepdim=True)
    mask = torch.ones(rows, dtype=torch.int8)
    mask[tokens:] = 0
    if cfg.get('model_sentinels'):
        assert dummy == 4 and world == 8 and experts == 256
        if cfg.get('model_concentrated'):
            generator = torch.Generator().manual_seed(777)
            x = torch.randn(1, HIDDEN, dtype=torch.bfloat16, generator=generator).repeat(rows, 1)
            ids = torch.arange(TOPK, dtype=torch.int32).repeat(rows, 1)
            probs = torch.rand(1, TOPK, generator=generator).repeat(rows, 1)
            probs /= probs.sum(dim=-1, keepdim=True)
        ids[tokens:] = torch.arange(rank * e, (rank + 1) * e, dtype=torch.int32).reshape(dummy, TOPK)
        x[tokens:] = 1
        probs[tokens:] = 1.0 / TOPK
        mask[tokens:] = 1
    sig = fingerprint([w13, w2, s13, s2, x, ids, probs, mask])
    weights = [list(torch_npu.npu_format_cast(w.to(dev), 29).unbind()) for w in (w13, w2)]
    scales = [list(s.view(torch.int32).to(torch.int64).to(dev).view(torch.uint64).unbind())
              for s in (s13, s2)]
    assert all(torch_npu.get_npu_format(w[0]) == 29 for w in weights)
    return experts, tokens, sig, [t.to(dev) for t in (x, ids, probs, mask)], weights, scales


def run_case(cfg, rank, world, dev, mode, outdir, refdir):
    experts, tokens, sig, (x, ids, probs, mask), (w1, w2), (s1, s2) = make_case(cfg, rank, world, dev)
    label = cfg['label']
    assert label.replace('_', '').isalnum()
    filename = f'{label}_rank{rank}.pt'
    group = dist.new_group(list(range(world)), backend='hccl') if cfg.get('fresh_group') else dist.group.WORLD
    sym = get_symm_buffer_for_mega_moe(
        group, experts, max(int(cfg.get('cap', 544)), len(x)), TOPK, HIDDEN, int(cfg.get('sym_inter', INTER)),
        max_recv_token_num=0, dispatch_quant_mode=2, dispatch_quant_out_dtype=torch.int8)

    def once():
        xx = x.clone() if cfg.get('async_pipeline') else x
        return mega_moe(xx, ids, probs, w1, w2, sym, l1_weights_sf=s1, l2_weights_sf=s2,
                        x_active_mask=mask, weight1_type=258, weight2_type=258)

    first = once()
    torch.npu.synchronize()
    outputs = [t.cpu() for t in first] if isinstance(first, (tuple, list)) else [first.cpu()]
    y = outputs[0][:tokens].float()
    assert torch.isfinite(y).all(), 'NONFINITE_OUTPUT'
    assert y.abs().max().item() > 1e-5, 'DEGENERATE_ZERO_OUTPUT'
    assert torch.count_nonzero(y).item() > y.numel() // 2, 'DEGENERATE_SPARSE_OUTPUT'
    if mode != 'record':
        ref = torch.load(refdir / filename, map_location='cpu', weights_only=True)
        assert ref['input_sha256'] == sig, 'INPUT_MISMATCH'
        assert len(ref['outputs']) == len(outputs)
        for a, b in zip(outputs, ref['outputs']):
            assert torch.equal(a, b), f'BASELINE_MISMATCH max_abs={(a.float()-b.float()).abs().max().item()}'
    for repetition in range(5):
        new = once()
        torch.npu.synchronize()
        new = list(new) if isinstance(new, (tuple, list)) else [new]
        assert all(torch.equal(a, b.cpu()) for a, b in zip(outputs, new)), f'UNSTABLE_{repetition}'
    if cfg.get('async_pipeline'):
        queued = [once() for _ in range(40)]
        torch.npu.synchronize()
        assert all(torch.equal(a, b.cpu()) for r in queued for a, b in zip(outputs, r)), 'ASYNC_PIPELINE_MISMATCH'
        print('ASYNC_PIPELINE_40_EXACT_PASS', rank, flush=True)
    if mode == 'record':
        assert not (outdir / filename).exists(), 'REFERENCE_NO_CLOBBER'
        torch.save({'input_sha256': sig, 'outputs': outputs}, outdir / filename)
    dist.barrier()
    result = dict(label=label, rank=rank, world=world, input_sha256=sig,
                  max_abs=y.abs().max().item(), rms=y.square().mean().sqrt().item(),
                  output_shape=list(y.shape), correctness='PASS', stable_repeats=5,
                  topo_type=sym.topo_type, rank_num_per_server=sym.rank_num_per_server, ccl_buffer_size=sym.ccl_buffer_size)
    if mode == 'perf':
        for _ in range(10):
            once()
        torch.npu.synchronize()
        samples = []
        for _ in range(int(cfg.get('iters', 30))):
            dist.barrier()
            torch.npu.synchronize()
            t0 = time.perf_counter()
            once()
            torch.npu.synchronize()
            samples.append((time.perf_counter() - t0) * 1e6)
        result['wall_us'] = samples
        result['median_wall_us'] = statistics.median(samples)
    maps = Path('/proc/self/maps').read_text()
    result['loaded_custom_libraries'] = sorted({s.split()[-1] for s in maps.splitlines()
                                               if 'libcust_opapi.so' in s or 'megamoe' in s.lower() and '.so' in s})
    print('CASE_RESULT ' + json.dumps(result), flush=True)
    (outdir / f'{label}_rank{rank}.json').write_text(json.dumps(result, indent=2))
    sym.destroy()
    if cfg.get('fresh_group'):
        dist.destroy_process_group(group)
    dist.barrier()


def main():
    configs_path, mode, output, reference = sys.argv[1:]
    assert mode in ('record', 'compare', 'perf')
    outdir, refdir = Path(output), Path(reference)
    outdir.mkdir(parents=True, exist_ok=True)
    rank, world = int(os.environ['RANK']), int(os.environ['WORLD_SIZE'])
    torch.npu.set_device(rank)
    torch.npu.config.allow_internal_format = True
    dev = torch.device(f'npu:{rank}')
    dist.init_process_group('hccl', timeout=timedelta(seconds=180))
    warm = torch.ones(8, device=dev)
    dist.all_reduce(warm)
    torch.npu.synchronize()
    for cfg in json.loads(Path(configs_path).read_text()):
        run_case(cfg, rank, world, dev, mode, outdir, refdir)
    dist.destroy_process_group()
    print(f'ALL_CASES_PASS rank={rank} mode={mode}', flush=True)


if __name__ == '__main__':
    main()
