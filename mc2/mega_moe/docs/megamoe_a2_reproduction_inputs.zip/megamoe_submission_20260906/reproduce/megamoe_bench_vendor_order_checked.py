"""Run the known correctness harness after the same vLLM bootstrap as serving."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

import torch
import torch_npu  # noqa: F401

ROOT = Path('/data1/megamoe_gain_20260905')
HARNESS = ROOT / 'megamoe_bench_buffer_contract.py'
EXPECTED_HARNESS = '5f704b0b86bd012e424f630ed78157d8e020970b664c92834be590653eb81435'
assert HARNESS.is_file() and hashlib.sha256(HARNESS.read_bytes()).hexdigest() == EXPECTED_HARNESS
assert len(sys.argv) == 5 and sys.argv[2] == 'compare', 'CORRECTNESS_ONLY_BEFORE_SERVE'
assert not torch.npu.is_initialized(), 'BOOTSTRAP_MUST_PRECEDE_DEVICE_INIT'
vendor = Path(os.environ['MMGAIN_EXPECTED_VENDOR'])
vllm_vendor = ROOT / 'vllm-ascend/vllm_ascend/_cann_ops_custom/vendors/custom_transformer'
expected_path = str(vendor) + ':' + str(vllm_vendor)
assert os.environ['ASCEND_CUSTOM_OPP_PATH'] == expected_path, 'EXPLICIT_VENDOR_PRIORITY_REQUIRED'
assert vendor.is_dir() and vllm_vendor.is_dir()

import vllm_ascend.utils as vllm_utils
vllm_utils.bootstrap_custom_op_env()
import vllm_ascend.vllm_ascend_C  # noqa: F401

assert not torch.npu.is_initialized(), 'CPU_BOOTSTRAP_INITIALIZED_NPU'
assert os.environ['ASCEND_CUSTOM_OPP_PATH'] == expected_path, 'VENDOR_PRIORITY_CHANGED'
rank = int(os.environ['RANK'])
output = Path(sys.argv[3])
assert output.is_dir()
before = output / f'vendor_preflight_rank{rank}.json'
assert not before.exists()
before.write_text(json.dumps(dict(rank=rank, vendor_path=expected_path,
                                 npu_initialized=False, harness_sha256=EXPECTED_HARNESS), indent=2))
runpy.run_path(str(HARNESS), run_name='__main__')

libraries = sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
                    if any(name in line for name in ('libcust_opapi', 'libcust_opmaster', 'libcust_opsproto'))})
expected_tiling = str((vendor / 'op_impl/ai_core/tbe/op_tiling/liboptiling.so').resolve())
expected_proto = str((vendor / 'op_proto/lib/linux/aarch64/libcust_opsproto_rt2.0.so').resolve())
expected_api = str((vendor / 'op_api/lib/libcust_opapi.so').resolve())
for required in (expected_tiling, expected_proto, expected_api):
    assert required in libraries, ('CANDIDATE_PROVIDER_NOT_LOADED', required, libraries)
legacy_libraries = [p for p in libraries if '/usr/local/Ascend/cann-9.1.0/opp/vendors/custom_transformer/' in p]
after = output / f'vendor_postflight_rank{rank}.json'
assert not after.exists()
after.write_text(json.dumps(dict(rank=rank, libraries=libraries, co_loaded_legacy_libraries=legacy_libraries,
                                provider_hashes={p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                                                 for p in (expected_tiling, expected_proto, expected_api)},
                                correctness_and_provider_gate='PASS'), indent=2))
print('MODEL_IMPORT_ORDER_AND_CORRECTNESS_PASS', rank, flush=True)
