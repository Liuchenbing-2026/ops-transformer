from pathlib import Path
from mmengine.config import Config
from ais_bench.benchmark.cli.config_manager import CustomConfigChecker
p=Path('/data1/megamoe_gain_20260905/aisbench/config_4k_1k_c16.py')
cfg=Config.fromfile(str(p));CustomConfigChecker(cfg,str(p)).check()
assert len(cfg.models)==len(cfg.datasets)==1
m=cfg.models[0];d=cfg.datasets[0]
assert m.max_out_len==1024 and m.batch_size==16 and m.generation_kwargs.temperature==0 and m.generation_kwargs.ignore_eos
assert cfg.summarizer.attr=='performance'
obj=d.type(path=d.path,reader_cfg=d.reader_cfg)
assert len(obj.test)==32 and len(obj.train)==0
assert all(isinstance(x['question'],str) and x['question'] for x in obj.test)
assert d.infer_cfg.retriever.type.__name__=='ZeroRetriever'
print('AIS_FULL_CONFIG_AND_REAL_DATA_LOADER_PASS train=0 test=32 out=1024 c=16')
