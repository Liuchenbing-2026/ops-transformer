"""Check EP8 prefix-sum partitioning; this does not simulate NPU concurrency."""

import argparse
import hashlib
import json
import random
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("header", type=Path)
args = parser.parse_args()
digest = hashlib.sha256(args.header.read_bytes()).hexdigest()
assert (
    digest
    in {
        "89e2d126d709eec91e2c11651bf1d4e528f0b27c48f88cb27396e08d30a8fa3d",  # NPU-validated raw header
        "b3f48e75345e863df6a523633677e33d24a97014d53f205cb8c763b7f7d5afec",  # token-equivalent formatted commit
    }
), "Header must match the verified raw or submission source"
rng = random.Random(20260906)
cases = 0
addresses = 0
for experts in (1, 2, 4, 31, 32, 33, 64, 128):
    for distribution in ("uniform", "one_source", "one_expert", "random"):
        counts = [
            [
                [
                    16
                    if distribution == "uniform"
                    else (512 if source == 0 else 0)
                    if distribution == "one_source"
                    else (128 if expert == 0 else 0)
                    if distribution == "one_expert"
                    else rng.randrange(65)
                    for expert in range(experts)
                ]
                for dest in range(8)
            ]
            for source in range(8)
        ]
        totals = [
            [sum(counts[s][d][g] for s in range(8)) for g in range(experts)]
            for d in range(8)
        ]
        expert_bases = [[sum(totals[d][:g]) for g in range(experts)] for d in range(8)]
        source_bases = [
            [
                [sum(counts[s][d][g] for s in range(source)) for g in range(experts)]
                for d in range(8)
            ]
            for source in range(8)
        ]
        for cap in (1, 4096, 65536):
            sent = {}
            received = {}
            for rank in range(8):
                for core in range(40):
                    peer = core % 8
                    lane = core // 8
                    peer_base = 0
                    local_base = 0
                    notifications = []
                    for wave in range(0, experts, 5):
                        end = min(wave + 5, experts)
                        g = wave + lane
                        send_base = peer_base + sum(totals[peer][wave : min(g, end)])
                        recv_base = local_base + sum(totals[rank][wave : min(g, end)])
                        if g < end:
                            ss = send_base + source_bases[rank][peer][g]
                            rs = recv_base + source_bases[peer][rank][g]
                            sk = (rank, peer, g)
                            rk = (peer, rank, g)
                            assert sk not in sent and rk not in received
                            sent[sk] = (
                                ss,
                                max(0, min(counts[rank][peer][g], cap - ss)),
                            )
                            received[rk] = (
                                rs,
                                max(0, min(counts[peer][rank][g], cap - rs)),
                            )
                        for g in range(wave, end):
                            peer_base += totals[peer][g]
                            local_base += totals[rank][g]
                            notifications.append(g)
                    assert notifications == list(range(experts))
                    assert local_base == sum(totals[rank]) and peer_base == sum(
                        totals[peer]
                    )
            assert sent == received and len(sent) == 8 * 8 * experts
            for (source, dest, g), (start, rows) in sent.items():
                expected = expert_bases[dest][g] + source_bases[source][dest][g]
                assert start == expected and rows == max(
                    0, min(counts[source][dest][g], cap - expected)
                )
            for dest in range(8):
                spans = sorted(
                    (start, start + rows)
                    for (source, d, g), (start, rows) in sent.items()
                    if d == dest and rows
                )
                assert not spans or (
                    spans[0][0] == 0 and spans[-1][1] == min(sum(totals[dest]), cap)
                )
                assert all(a[1] == b[0] for a, b in zip(spans, spans[1:]))
            cases += 1
            addresses += len(sent)
print(
    json.dumps(
        dict(
            status="PASS",
            cases=cases,
            source_destination_expert_addresses=addresses,
            kernel_sha256=digest,
            scope="Integer address partition and notification order only; not NPU concurrency or performance.",
        )
    )
)
