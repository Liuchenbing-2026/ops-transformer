#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import json,statistics
t=Path('/data1/megamoe_gain_20260905/bf16_opt_20260907/model_v3')
assert (t/'controller_v2.rc').read_text().strip()=='0'
assert (t/'evaluation_v2.rc').read_text().strip()=='0'
rows=[];input_seeds=None
for arm in ['on_F1','off_E1','off_E2','on_F2']:
 out=t/'results'/arm
 assert (out/'stop.rc').read_text().strip()=='0'
 assert (out/'acceptance_pass.json').exists()
 if arm.startswith('on_'):
  assert json.loads((out/'old_new_precision_pass.json').read_text())['status']=='PASS'
 p=json.loads((out/'prefill/probe_results.json').read_text())
 assert len(p['samples'])==12
 seeds=[x['seed'] for x in p['samples']]
 if input_seeds is None:input_seeds=seeds
 assert seeds==input_seeds
 assert all(x['response']['usage']['prompt_tokens']==4096 and x['response']['usage']['completion_tokens']==1 for x in p['samples'])
 rows.append(dict(arm=arm,status='PASS',prefill_p50_ms=p['summary']['median_ms'],samples_ms=[x['ms'] for x in p['samples']]))
on=statistics.mean(x['prefill_p50_ms'] for x in rows if x['arm'].startswith('on_'))
off=statistics.mean(x['prefill_p50_ms'] for x in rows if x['arm'].startswith('off_'))
summary=dict(status='PASS',scope='4096 input, 1 output, concurrency 1 HTTP latency; not AISBench throughput',on_ms=on,off_ms=off,on_latency_reduction_pct=(1-on/off)*100,rows=rows,kernel_commit='e204056851f94a8b60b386eaa7689a0b1f3381ba',all_on_fixed_prompt_old_new_precision_pass=True)
p=t/'prefill_performance_summary.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
PY
