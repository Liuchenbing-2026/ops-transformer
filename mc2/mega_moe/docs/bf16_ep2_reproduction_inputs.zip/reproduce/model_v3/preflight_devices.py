from pathlib import Path
import hashlib,json,re,socket,subprocess

t=Path('/data1/megamoe_gain_20260905/bf16_opt_20260907/model_v3')
text=subprocess.check_output(['npu-smi','info'],universal_newlines=True)
memory=[int(x) for x in re.findall(r'(\d+)\s*/\s*65536',text)]
assert len(memory)==8
selected=[0,5]
assert all(memory[i]<6000 and 'No running processes found in NPU %d'%i in text for i in selected),('SELECTED_DEVICE_BUSY',memory)
for port in [8077,29541]:
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s.bind(('0.0.0.0',port))
for row in json.loads((t/'source_manifest.json').read_text())['files']:
    assert hashlib.sha256((t/'vllm-ascend-bf16'/row['path']).read_bytes()).hexdigest()==row['sha256']
model=json.loads((t/'model_ready.json').read_text())
assert model['status']=='PASS' and model['tensor_dtypes']=={'BF16':1045}
for row in model['files']:
    p=Path(row['path']);assert p.stat().st_size==row['size'] and p.stat().st_mtime_ns==row['mtime_ns'], 'MODEL_CHANGED_AFTER_SHA_VERIFICATION'
print('SELECTED_TWO_DEVICES_PORTS_AND_SOURCE_CLEAR',selected,memory,flush=True)
