"""Reuse the accepted service identity, correctness and repeatability gates."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import urllib.request

root = Path('/data1/megamoe_gain_20260905/bf16_opt_20260907/model_v3')
arm = sys.argv[1]
assert arm in ('off_E1', 'on_F1', 'on_F2', 'off_E2')
out = root / 'results' / arm
pid = int((out / 'server.pid').read_text())


def stat(text):
    a = text[text.rfind(')') + 2:].split()
    return dict(state=a[0], ppid=int(a[1]), pgid=int(a[2]), sid=int(a[3]), start=int(a[19]))


initial = stat((out / 'server.initial_stat').read_text())
current = stat(Path('/proc/%d/stat' % pid).read_text())
assert current['start'] == initial['start'] and current['pgid'] == current['sid'] == pid
cmd = Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
assert b'/data2/weights/Qwen3.6-35B-A3B' in cmd and b'8077' in cmd
env = dict(x.split(b'=', 1) for x in Path('/proc/%d/environ' % pid).read_bytes().split(b'\0') if b'=' in x)
expected = b'1' if arm.startswith('on_') else b'0'
assert env[b'MEGAMOE'] == expected and env[b'HCCL_DETERMINISTIC'] == b'true'
assert env[b'MEGAMOE_SKIP_COMPILED'] == b'0'
assert env[b'ASCEND_CUSTOM_OPP_PATH'].startswith(str(Path('/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v3/packages/vendors/mmbf16v3_transformer')).encode() + b':')
identities = {}
for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        st = stat((p / 'stat').read_text())
        if st['pgid'] == pid and st['sid'] == pid:
            st['cmd'] = (p / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            identities[p.name] = st
    except (FileNotFoundError, ProcessLookupError):
        continue
assert len(identities) >= 3
(out / 'startup_process_manifest.json').write_text(json.dumps(identities, indent=2))
(out / 'ready_identity.json').write_text(json.dumps(dict(pid=pid, arm=arm, start=current['start'],
    command=[x.decode() for x in cmd if x], environment={k.decode(): v.decode() for k,v in env.items()
    if k in (b'MEGAMOE',b'HCCL_DETERMINISTIC',b'MEGAMOE_SKIP_COMPILED',b'ASCEND_CUSTOM_OPP_PATH',b'PYTHONPATH')}), indent=2))
probe = root / 'probe_stability_only.py'
assert hashlib.sha256(probe.read_bytes()).hexdigest() == 'ce2df1ab889b651ca2e1f2bf94975bb6a21e54bbee0710f4e1ab83b7d6ae6852'
assert not (out / 'probe.log').exists()
with (out / 'probe.log').open('x') as f:
    run = subprocess.run([sys.executable, str(probe), '8077', str(out / 'probe')], stdout=f, stderr=subprocess.STDOUT, timeout=240)
(out / 'probe.rc').write_text(str(run.returncode) + '\n')
assert run.returncode == 0
repeats = json.loads((out / 'probe/stability_2k.json').read_text())
assert len(repeats) == 3 and all(x['choices'][0]['logprobs'] == repeats[0]['choices'][0]['logprobs'] for x in repeats)
payload = dict(model='qwen3.6-35b-a3b-bf16', messages=[
    dict(role='system',content='The repeated text below is neutral filler. Follow only the final user instruction.'),
    dict(role='user',content='Neutral filler. '*700+'\nFinal instruction: Reply with exactly the number 42. No explanation.')],
    max_tokens=16,temperature=0,stream=False,chat_template_kwargs={'enable_thinking':False})
request = urllib.request.Request('http://127.0.0.1:8077/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=120) as response:
    result = json.load(response)
(out / 'long_semantic.json').write_text(json.dumps(dict(payload=payload,response=result),indent=2))
assert 512 <= result['usage']['prompt_tokens'] <= 4096
assert result['choices'][0]['message']['content'].strip() == '42'
log=(out/'server.log').read_text(errors='replace')
assert ('CANN MegaMoe sym-buffer alloc:' in log) == arm.startswith('on_'), 'ACTUAL_MEGAMOE_PATH_GATE'
assert b'--dtype' in cmd and b'bfloat16' in cmd and b'--quantization' not in cmd
assert env[b'ASCEND_RT_VISIBLE_DEVICES']==b'0,5'
(out / 'acceptance_pass.json').write_text(json.dumps(dict(status='PASS',arm=arm,three_2k_logprobs_identical=True),indent=2))
print('ACCURACY_ARM_CORRECTNESS_STABILITY_PASS', arm, flush=True)

# Fixed-prompt whole-model comparison against the preserved old BF16 kernel.
if arm.startswith('on_'):
    baseline = Path('/data1/megamoe_gain_20260905/bf16_20260907/ep2_qwen36_gmmfix/results/on_F1/probe')
    prior = json.loads((baseline/'stability_2k.json').read_text())
    assert repeats[0]['choices'][0]['text'] == prior[0]['choices'][0]['text'], 'OLD_NEW_2K_TOKEN_MISMATCH'
    assert repeats[0]['choices'][0]['logprobs'] == prior[0]['choices'][0]['logprobs'], 'OLD_NEW_2K_LOGPROBS_MISMATCH'
    current4k = json.loads((out/'probe/correctness.json').read_text())['long_repeats']
    prior4k = json.loads((baseline/'correctness.json').read_text())['long_repeats']
    assert current4k[0]['choices'][0]['text'] == prior4k[0]['choices'][0]['text'], 'OLD_NEW_4K_TOKEN_MISMATCH'
    (out/'old_new_precision_pass.json').write_text(json.dumps(dict(status='PASS',tokens_2k_identical=True,logprobs_2k_exact=True,tokens_4k_identical=True,baseline=str(baseline)),indent=2))
