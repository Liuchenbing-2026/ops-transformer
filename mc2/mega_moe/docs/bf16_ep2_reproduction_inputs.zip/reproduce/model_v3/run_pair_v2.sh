#!/usr/bin/env bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_opt_20260907/model_v3
test ! -e "$task/controller_v2.log"
exec > "$task/controller_v2.log" 2>&1
exec 9>/var/lock/megamoe_q36.lock
flock -n 9
printf '%s\n' "$$" > "$task/controller_v2.pid"
cat /proc/$$/stat > "$task/controller_v2.initial_stat"
active_arm=''
cleanup() {
  rc=$?
  trap - EXIT
  printf '%s\n' "$rc" > "$task/evaluation_v2.rc"
  if test -n "$active_arm"; then
    out=$task/results/$active_arm
    if test -f "$out/server.pid" && test ! -e "$out/stop.log"; then
      set +e
      docker exec mm_bf16_serve_20260907 python3 "$task/stop_owned_bf16_v2.py" "$active_arm" > "$out/stop.log" 2>&1
      stop_rc=$?
      set -e
      printf '%s\n' "$stop_rc" > "$out/stop.rc"
      if test "$stop_rc" -ne 0; then printf '%s\n' OWNED_STOP_REQUIRES_REVIEW;exit 1;fi
    fi
  fi
  printf '%s\n' "$rc" > "$task/controller_v2.rc"
  exit "$rc"
}
trap cleanup EXIT
for arm in on_F1 off_E1 off_E2 on_F2; do
  active_arm=$arm
  out=$task/results/$arm
    mode=0
    if [[ "$arm" = on_* ]]; then mode=1;fi
    test ! -e "$out"
    docker exec -d mm_bf16_serve_20260907 bash -c 'exec setsid bash "$1/serve_bf16_v2.sh" "$2" "$3" > "$1/launch_$3.log" 2>&1' bash "$task" "$mode" "$arm"
  printf '%s\n' "$arm WAIT_HEALTH $(date -u +%FT%TZ)" > "$task/progress.txt"
  end=$((SECONDS+1200))
  record_deadline=$((SECONDS+30))
  while test "$SECONDS" -lt "$end"; do
    if curl --max-time 3 --fail -s http://127.0.0.1:8077/health > /dev/null; then break;fi
    if test ! -f "$out/server.initial_stat" && test "$SECONDS" -gt "$record_deadline"; then
      cat "$task/launch_$arm.log"
      exit 1
    fi
    if test -f "$out/server.log" && grep -qE 'NPUModelRunner init failed|Engine core initialization failed|Worker failed with error' "$out/server.log"; then
      printf '%s\n' TERMINAL_STARTUP_ERROR_FAIL_FAST
      exit 1
    fi
    if test -f "$out/server.initial_stat"; then
      docker exec mm_bf16_serve_20260907 python3 "$task/server_alive.py" "$out" || exit 1
    fi
    sleep 5
  done
  test "$SECONDS" -lt "$end"
  printf '%s\n' "$arm CORRECTNESS_STABILITY $(date -u +%FT%TZ)" > "$task/progress.txt"
  docker exec mm_bf16_serve_20260907 python3 "$task/acceptance_bf16_v2.py" "$arm"
  printf '%s\n' "$arm PREFILL_PERFORMANCE $(date -u +%FT%TZ)" > "$task/progress.txt"
  docker exec mm_bf16_serve_20260907 python3 "$task/prefill_after_stability_v2.py" 8077 "$out/prefill" > "$out/prefill.log" 2>&1
  docker exec mm_bf16_serve_20260907 python3 "$task/stop_owned_bf16_v2.py" "$arm" > "$out/stop.log" 2>&1
  printf '0\n' > "$out/stop.rc"
  active_arm=''
done
printf '%s\n' FOUR_ROUNDS_COMPLETE > "$task/progress.txt"
