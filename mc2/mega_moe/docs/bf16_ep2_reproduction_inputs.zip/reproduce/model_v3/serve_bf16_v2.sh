#!/usr/bin/env bash
set -euo pipefail
root=/data1/megamoe_gain_20260905
task=/data1/megamoe_gain_20260905/bf16_opt_20260907/model_v3
mode=$1
round=$2
[[ "$mode" = 0 || "$mode" = 1 ]]
[[ "$round" =~ ^(on|off)_[A-Z][0-9]+$ ]]
test "$(cat "$task/cpu_tests.rc")" = 0
test -f "$task/model_ready.json"
python3 "$task/preflight_devices.py"
out=$task/results/$round
test ! -e "$out"
mkdir -p "$out"
exec > "$out/server.log" 2>&1
printf '%s\n' "$$" > "$out/server.pid"
cat /proc/$$/stat > "$out/server.initial_stat"
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,5
vend=/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v3/packages/vendors/mmbf16v3_transformer
va=$task/vllm-ascend-bf16
export ASCEND_CUSTOM_OPP_PATH="$vend:$va/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
export LD_LIBRARY_PATH="$vend/op_api/lib:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$va:$root/source/torch_extension:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=$root/torch_extensions
export VLLM_CACHE_ROOT=/data1/megamoe_gain_20260905/bf16_20260907/ep2_qwen36/vllm_cache
export MAX_JOBS=8
export HCCL_DETERMINISTIC=true
export MEGAMOE="$mode"
export MEGAMOE_SKIP_COMPILED=0
export SHARED_EXPERT_OVERLAP=0
export PREFIX_CACHING=0
export HCCL_OP_EXPANSION_MODE=AIV
export HCCL_BUFFSIZE=200
export HCCL_CONNECT_TIMEOUT=120
export HCCL_EXEC_TIMEOUT=120
export OMP_PROC_BIND=false
export OMP_NUM_THREADS=1
export TASK_QUEUE_ENABLE=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export VLLM_ASCEND_BALANCE_SCHEDULING=1
export VLLM_ASCEND_ENABLE_FLASHCOMM1=1
export VLLM_USE_V2_MODEL_RUNNER=0
export MODEL_PATH=/data2/weights/Qwen3.6-35B-A3B
export SERVED_MODEL_NAME=qwen3.6-35b-a3b-bf16
python3 - <<'PY'
import acl
print('ACL_TOOLKIT_IMPORT_GATE_PASS',acl.__file__,flush=True)
PY
if [[ "$mode" = 1 ]]; then
    additional_config='{"enable_fused_mc2":2,"mega_moe_min_tokens":512,"mega_moe_skip_compiled":false,"multistream_overlap_shared_expert":false}'
else
    additional_config='{"enable_fused_mc2":0,"multistream_overlap_shared_expert":false}'
fi
exec vllm serve "$MODEL_PATH" \
  --host 127.0.0.1 --port 8077 --data-parallel-size 1 --tensor-parallel-size 2 \
  --enable-expert-parallel --seed 1024 --served-model-name "$SERVED_MODEL_NAME" \
  --max-num-seqs 32 --max-model-len 32768 --max-num-batched-tokens 4096 \
  --trust-remote-code --gpu-memory-utilization 0.90 --dtype bfloat16 \
  --enable-chunked-prefill --no-enable-prefix-caching \
  --additional-config "$additional_config" \
  --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY"}'
