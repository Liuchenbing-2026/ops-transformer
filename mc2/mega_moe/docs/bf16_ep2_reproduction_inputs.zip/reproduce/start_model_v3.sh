#!/usr/bin/env bash
set -euo pipefail
r=/data1/megamoe_gain_20260905/bf16_opt_20260907
test "$(cat "$r/results/v3_perf_controller.rc")" = 0
test ! -e "$r/model_v3/controller_v2.log"
docker exec mm_bf16_serve_20260907 python3 "$r/model_v3/preflight_devices.py"
bash -n "$r/model_v3/run_pair_v2.sh"
nohup bash "$r/model_v3/run_pair_v2.sh" > "$r/model_v3/controller_launch.log" 2>&1 < /dev/null &
printf '%s\n' BF16_V3_MODEL_EVALUATION_DISPATCHED
