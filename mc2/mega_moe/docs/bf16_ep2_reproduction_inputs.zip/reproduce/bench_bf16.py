"""BF16 adaptation of the established MegaMoe correctness/performance harness.

Same-runtime unquantized GMM reference, exact old/new kernel comparison,
consecutive asynchronous calls, then gated timing in a separate invocation.
"""
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

import torch
import torch.distributed as dist
import torch_npu

mode, output, reference = sys.argv[1:]
assert mode in ('record', 'compare', 'perf')
outdir, refdir = Path(output), Path(reference)
assert outdir.is_dir()
vendor = Path(os.environ['MMGAIN_EXPECTED_VENDOR'])
expected_env = os.environ['ASCEND_CUSTOM_OPP_PATH']
assert expected_env.split(':')[0] == str(vendor)
assert not torch.npu.is_initialized()
import vllm_ascend.utils as vu
vu.bootstrap_custom_op_env()
import vllm_ascend.vllm_ascend_C
assert os.environ['ASCEND_CUSTOM_OPP_PATH'] == expected_env
assert not torch.npu.is_initialized()
from cann_ops_transformer.ops.mega_moe import get_symm_buffer_for_mega_moe, mega_moe, _get_mega_moe_ccl_buffer_size
from vllm_ascend.ops.fused_moe.moe_mlp import unquant_apply_mlp
from vllm_ascend.ops.fused_moe.moe_comm_method import _append_cann_megamoe_dummy_tokens

rank, world = int(os.environ['RANK']), int(os.environ['WORLD_SIZE'])
assert world == 2
H, I, E, K = 2048, 512, 256, 8
# The accepted service overrides HCCL_BUFFSIZE for its MC2 process group.
# Reproduce that exact 206-MiB group option, not merely the 200-MiB env.
buffer_mb = int(_get_mega_moe_ccl_buffer_size(world,E,2080,K,H,max_recv_token_num=33280,dispatch_quant_mode=2,dispatch_quant_out_dtype=torch.int8))
assert buffer_mb == 206, ('SERVICE_GROUP_BUFFER_CHANGED', buffer_mb)
options = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
options.hccl_config = {'hccl_buffer_size': buffer_mb}
torch.npu.set_device(rank)
dev = torch.device('npu:%d' % rank)
dist.init_process_group('hccl', timeout=timedelta(seconds=180), pg_options=options)
warm = torch.ones(8, device=dev)
dist.all_reduce(warm)
torch.npu.synchronize()
local_e = E // world
torch.manual_seed(1024 + rank)
cpu_w1 = (torch.randn(local_e, H, 2*I, dtype=torch.bfloat16)*0.01).contiguous()
cpu_w2 = (torch.randn(local_e, I, H, dtype=torch.bfloat16)*0.01).contiguous()
def fingerprint(ts):
    h = hashlib.sha256()
    for tensor in ts:
        a=tensor.detach().cpu().contiguous()
        h.update(str((tuple(a.shape),a.dtype)).encode())
        h.update(a.view(torch.uint8).numpy().tobytes())
    return h.hexdigest()
weight_sha=fingerprint([cpu_w1,cpu_w2])
w1,w2=cpu_w1.to(dev),cpu_w2.to(dev)
del cpu_w1,cpu_w2
split1=[w.clone() for w in w1.unbind()]
split2=[w.clone() for w in w2.unbind()]
assert torch_npu.get_npu_format(w1)==2 and all(torch_npu.get_npu_format(w)==2 for w in split1)
sym=get_symm_buffer_for_mega_moe(dist.group.WORLD,E,2080,K,H,2*I,max_recv_token_num=0,dispatch_quant_mode=0,dispatch_quant_out_dtype=None)
assert sym.ccl_buffer_size == 2*buffer_mb*1024*1024, ('ACTUAL_CCL_BUFFER_MISMATCH',sym.ccl_buffer_size,buffer_mb)
print('ACTUAL_SERVICE_GROUP_BUFFER_PASS', rank, buffer_mb, sym.ccl_buffer_size, flush=True)
cases=[('uniform256',256,'uniform'),('uniform2048',2048,'uniform'),('skew512',512,'skew'),('concentrated1024',1024,'concentrated')]
rows=[]

def gather(tensor):
    result=[torch.empty_like(tensor) for _ in range(world)]
    dist.all_gather(result,tensor)
    return torch.cat(result,dim=0)

def reference_mlp(x,ids,probs):
    # Reference communicates complete inputs once, routes locally, applies
    # standard BF16 GMM, and accumulates weighted local outputs in FP32.
    xx,ii,pp=gather(x),gather(ids).cpu(),gather(probs).cpu()
    slots=((ii>=rank*local_e)&(ii<(rank+1)*local_e)).nonzero()
    experts=ii[slots[:,0],slots[:,1]].long()-rank*local_e
    order=torch.argsort(experts,stable=True)
    slots,experts=slots[order],experts[order]
    groups=torch.bincount(experts,minlength=local_e).to(dev,dtype=torch.int64)
    token_rows=slots[:,0].to(dev)
    routed=xx.index_select(0,token_rows)
    local,_=unquant_apply_mlp(hidden_states=routed,w1=w1,w2=w2,group_list=groups,group_list_type=1,need_trans=False)
    weighted=local.float()*pp[slots[:,0],slots[:,1]].to(dev)[:,None]
    combined=torch.zeros(xx.shape,device=dev,dtype=torch.float32)
    combined.index_add_(0,token_rows,weighted)
    dist.all_reduce(combined)
    return combined[rank*len(x):(rank+1)*len(x)]

with torch.inference_mode():
    for case_index,(label,tokens,distribution) in enumerate(cases):
        torch.manual_seed(2000+rank+case_index*100)
        x=torch.randn(tokens,H,dtype=torch.bfloat16)
        scores=torch.rand(tokens,E)
        if distribution=='skew':scores[:,:local_e]+=2
        if distribution=='concentrated':scores[:,:K]+=2
        ids=scores.topk(K,dim=-1).indices.to(torch.int32)
        probs=torch.rand(tokens,K);probs/=probs.sum(dim=-1,keepdim=True)
        input_sha=fingerprint([x,ids,probs])
        x,ids,probs,mask,original_tokens=_append_cann_megamoe_dummy_tokens(x.to(dev),ids.to(dev),probs.to(dev),None,E,rank,world,dummy_cache={})
        assert original_tokens==tokens and len(x)==tokens+16
        def once():
            return mega_moe(x,ids,probs,split1,split2,sym,l1_weights_sf=None,l2_weights_sf=None,x_active_mask=mask,weight1_type=None,weight2_type=None)
        first=once();torch.npu.synchronize()
        outputs=[a.cpu() for a in first]
        y=outputs[0][:tokens].float()
        assert torch.isfinite(y).all() and torch.count_nonzero(y)>y.numel()//2
        fname=label+'_rank%d.pt'%rank
        if mode!='record':
            old=torch.load(refdir/fname,map_location='cpu',weights_only=True)
            assert old['weight_sha256']==weight_sha and old['input_sha256']==input_sha
            assert all(torch.equal(a,b) for a,b in zip(outputs,old['outputs'])),'BASELINE_BITWISE_MISMATCH'
        metrics={}
        if mode!='perf':
            expected=reference_mlp(x,ids,probs)[:tokens].cpu().float()
            err=y-expected
            rel_l2=float(err.norm()/expected.norm().clamp_min(1e-12))
            cosine=float(torch.nn.functional.cosine_similarity(y.flatten(),expected.flatten(),dim=0))
            metrics=dict(reference_max_abs_diff=float(err.abs().max()),reference_relative_l2=rel_l2,reference_cosine=cosine)
            assert rel_l2<0.02 and cosine>0.9995,('GMM_REFERENCE_MISMATCH',metrics)
            torch.testing.assert_close(y,expected,rtol=0.02,atol=0.0002)
            for _ in range(5):
                new=once();torch.npu.synchronize()
                assert all(torch.equal(a,b.cpu()) for a,b in zip(outputs,new)),'SYNC_REPEAT_MISMATCH'
            queued=[once() for _ in range(20)]
            torch.npu.synchronize()
            assert all(torch.equal(a,b.cpu()) for new in queued for a,b in zip(outputs,new)),'ASYNC_REPEAT_MISMATCH'
            del queued
        if mode=='record':
            assert not (outdir/fname).exists()
            torch.save(dict(weight_sha256=weight_sha,input_sha256=input_sha,outputs=outputs),outdir/fname)
        row=dict(label=label,rank=rank,tokens_per_rank=tokens,active_sentinels_per_rank=16,weight_sha256=weight_sha,input_sha256=input_sha,mode=mode,status='PASS',reference_metrics=metrics)
        if mode=='perf':
            for _ in range(10):once()
            torch.npu.synchronize()
            samples=[]
            for _ in range(30):
                dist.barrier();torch.npu.synchronize()
                start=time.perf_counter();once();torch.npu.synchronize()
                samples.append((time.perf_counter()-start)*1000)
            row.update(samples_ms=samples,median_ms=statistics.median(samples))
        rows.append(row)
        print('CASE_RESULT',json.dumps(row),flush=True)
        (outdir/(label+'_rank%d.json'%rank)).write_text(json.dumps(row,indent=2))
        dist.barrier()
maps=Path('/proc/self/maps').read_text()
loaded=sorted({s.split()[-1] for s in maps.splitlines() if 'libcust_opapi.so' in s})
assert str(vendor/'op_api/lib/libcust_opapi.so') in loaded,('WRONG_VENDOR_API',loaded)
(outdir/('complete_rank%d.json'%rank)).write_text(json.dumps(dict(status='PASS',rank=rank,mode=mode,cases=len(rows),vendor=str(vendor),loaded=loaded,topo_type=sym.topo_type,ccl_buffer_size=sym.ccl_buffer_size),indent=2))
sym.destroy();dist.barrier();dist.destroy_process_group()
print('BF16_ALL_CASES_PASS',rank,mode,flush=True)
