from pathlib import Path
import hashlib,json,random
import sys
p=Path(sys.argv[1]); expected_sha=sys.argv[2]; output=Path(sys.argv[3])
assert not output.exists()
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected_sha
rng=random.Random(20260907);cases=addresses=0
world,cores,wave_size=2,40,20
for experts in (1,2,19,20,21,32,127,128,129,256):
    for distribution in ('uniform','one_source','one_expert','random','empty'):
        counts=[[[16 if distribution=='uniform' else (512 if source==0 else 0) if distribution=='one_source' else (128 if expert==0 else 0) if distribution=='one_expert' else rng.randrange(65) if distribution=='random' else 0 for expert in range(experts)] for dest in range(world)] for source in range(world)]
        totals=[[sum(counts[s][d][g] for s in range(world)) for g in range(experts)] for d in range(world)]
        bases=[[sum(totals[d][:g]) for g in range(experts)] for d in range(world)]
        sb=[[[sum(counts[s][d][g] for s in range(source)) for g in range(experts)] for d in range(world)] for source in range(world)]
        for cap in (1,4096,65536):
            sent={};received={}
            for rank in range(world):
                for core in range(cores):
                    peer,lane=core%world,core//world
                    peer_base=local_base=0;notifications=[]
                    for wave in range(0,experts,wave_size):
                        end=min(wave+wave_size,experts);g=wave+lane
                        send_base=peer_base+sum(totals[peer][wave:min(g,end)])
                        recv_base=local_base+sum(totals[rank][wave:min(g,end)])
                        if g<end:
                            ss=send_base+sb[rank][peer][g];rs=recv_base+sb[peer][rank][g]
                            sk=(rank,peer,g);rk=(peer,rank,g)
                            assert sk not in sent and rk not in received
                            sent[sk]=(ss,max(0,min(counts[rank][peer][g],cap-ss)))
                            received[rk]=(rs,max(0,min(counts[peer][rank][g],cap-rs)))
                        for g in range(wave,end):
                            peer_base+=totals[peer][g];local_base+=totals[rank][g];notifications.append(g)
                    assert notifications==list(range(experts))
                    assert local_base==sum(totals[rank]) and peer_base==sum(totals[peer])
            assert sent==received and len(sent)==world*world*experts
            for (source,dest,g),(start,rows) in sent.items():
                expected=bases[dest][g]+sb[source][dest][g]
                assert start==expected and rows==max(0,min(counts[source][dest][g],cap-expected))
            for dest in range(world):
                spans=sorted((a,a+n) for (source,d,g),(a,n) in sent.items() if d==dest and n)
                assert not spans or spans[0][0]==0 and spans[-1][1]==min(sum(totals[dest]),cap)
                assert all(a[1]==b[0] for a,b in zip(spans,spans[1:]))
            cases+=1;addresses+=len(sent)
# BF16 copy: 16K elements per 32KiB UB buffer, two disjoint slots; tail
# remains contiguous and 32B aligned for the validated hidden sizes.
for hidden in (512,1024,2048,4096,7168,8192):
    for rows in (0,1,3,8,9,128,2048,33280):
        total=rows*hidden
        pieces=[(a,min(16384,total-a)) for a in range(0,total,16384)]
        assert sum(n for a,n in pieces)==total
        assert all(n*2<=32768 and n*2%32==0 for a,n in pieces)
out=dict(status='PASS',cases=cases,addresses=addresses,kernel_sha256=expected_sha,scope='Static address coverage, clipping, notification order and DMA chunks; NPU race/correctness/performance still required.')
output.write_text(json.dumps(out,indent=2))
print(json.dumps(out))
