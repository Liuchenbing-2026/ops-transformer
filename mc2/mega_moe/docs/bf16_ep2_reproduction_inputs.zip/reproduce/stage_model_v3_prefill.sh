#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import ast,hashlib,json,shutil,subprocess
r=Path('/data1/megamoe_gain_20260905/bf16_opt_20260907')
old=Path('/data1/megamoe_gain_20260905/bf16_20260907/ep2_qwen36_gmmfix')
t=r/'model_v3';assert not t.exists()
assert (r/'results/v3_perf_controller.rc').read_text().strip()=='0'
assert json.loads((r/'results/v3_selected_kernel_verified.json').read_text())['status']=='PASS'
t.mkdir();(t/'results').mkdir()
names=['serve_bf16_v2.sh','run_pair_v2.sh','acceptance_bf16_v2.py','prefill_after_stability_v2.py','probe_stability_only.py','preflight_devices.py','server_alive.py','stop_owned_bf16_v2.py','ais_config.py','verify_perf_v2.py','summarize_perf.py']
rows=[]
for name in names:
 raw=(old/name).read_bytes();assert b'\r' not in raw and not raw.startswith(b'\xef\xbb\xbf')
 text=raw.decode().replace(str(old),str(t))
 text=text.replace('task=$root/bf16_20260907/ep2_qwen36_gmmfix','task='+str(t))
 text=text.replace('vend=$root/package_v4/packages/vendors/mmgainv4_transformer','vend='+str(r/'package_v3/packages/vendors/mmbf16v3_transformer'))
 text=text.replace('/data1/megamoe_gain_20260905/package_v4/packages/vendors/mmgainv4_transformer',str(r/'package_v3/packages/vendors/mmbf16v3_transformer'))
 if name=='run_pair_v2.sh':
  # Both benchmark modes now use the same process-wide exclusion lock.
  text=text.replace('/var/lock/megamoe_ab.lock','/var/lock/megamoe_q36.lock')
  needle='  printf \'%s\\n\' "$arm AISBENCH_4K_1K_C16 $(date -u +%FT%TZ)" > "$task/progress.txt"'
  assert needle in text
  gate='  if [[ "$arm" = on_F1 ]]; then python3 "$task/screen_prefill.py" "$arm"; fi\n'
  # Keep the four controlled starts, correctness gates and prefill samples.
  # No long throughput benchmark while prefill still regresses.
  begin=text.index(needle)
  finish=text.index('  docker exec mm_bf16_serve_20260907 python3 "$task/stop_owned_bf16_v2.py" "$arm" > "$out/stop.log" 2>&1',begin)
  text=text[:begin]+text[finish:]
 if name=='summarize_perf.py':
  text=text.replace('Prior INT8 V4 kernel optimization is not a BF16 kernel optimization. No full-model lossless accuracy claim.','This run tests the BF16 V3 batched-copy, EP2 wave-dispatch and IPC combine synchronization kernel. Fixed-prompt precision evidence is scoped to the tested prompts and does not prove universal full-model losslessness.')
 if name=='stop_owned_bf16_v2.py':
  needle="(out / 'stop_status.txt').write_text('OWNED_SERVER_STOPPED_PORT_PROCESSES_DEVICES_CLEAR\\n')"
  assert needle in text
  text=text.replace(needle,"subprocess.run([sys.executable, str(root / 'preflight_devices.py')], check=True)\n"+needle)
 if name=='acceptance_bf16_v2.py':
  text+='\n# Fixed-prompt whole-model comparison against the preserved old BF16 kernel.\n'
  text+="if arm.startswith('on_'):\n"
  text+="    baseline = Path("+repr(str(old/ 'results/on_F1/probe'))+")\n"
  text+="    prior = json.loads((baseline/'stability_2k.json').read_text())\n"
  text+="    assert repeats[0]['choices'][0]['text'] == prior[0]['choices'][0]['text'], 'OLD_NEW_2K_TOKEN_MISMATCH'\n"
  text+="    assert repeats[0]['choices'][0]['logprobs'] == prior[0]['choices'][0]['logprobs'], 'OLD_NEW_2K_LOGPROBS_MISMATCH'\n"
  text+="    current4k = json.loads((out/'probe/correctness.json').read_text())['long_repeats']\n"
  text+="    prior4k = json.loads((baseline/'correctness.json').read_text())['long_repeats']\n"
  text+="    assert current4k[0]['choices'][0]['text'] == prior4k[0]['choices'][0]['text'], 'OLD_NEW_4K_TOKEN_MISMATCH'\n"
  text+="    (out/'old_new_precision_pass.json').write_text(json.dumps(dict(status='PASS',tokens_2k_identical=True,logprobs_2k_exact=True,tokens_4k_identical=True,baseline=str(baseline)),indent=2))\n"
 data=text.encode();p=t/name;p.write_bytes(data)
 if name.endswith('.sh'):subprocess.run(['bash','-n',str(p)],check=True)
 else:ast.parse(text)
 rows.append(dict(path=name,old_sha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256(data).hexdigest()))
screen="""from pathlib import Path
import json,statistics,sys
t=Path(TASK_ROOT);old=Path(BASELINE_ROOT);arm=sys.argv[1]
out=t/'results'/arm
new=json.loads((out/'prefill/probe_results.json').read_text())['summary']['median_ms']
previous=[json.loads((old/'results'/a/'perf_verified.json').read_text())['prefill_p50_ms'] for a in ['off_E1','off_E2']]
baseline=statistics.mean(previous)
needs_profile=new>1.10*baseline
(out/'prefill_screen.json').write_text(json.dumps(dict(status='NEEDS_PROFILE' if needs_profile else 'CONTINUE_CONTROLLED_ABBA',new_on_ms=new,previous_off_ms=baseline,ratio=new/baseline,screen_only=True),indent=2))
if needs_profile:
 print('PREFILL_SCREEN_CLEAR_REGRESSION_VS_PRESERVED_OFF_STOP_BEFORE_LONG_BENCHMARK',new,baseline,flush=True)
 sys.exit(42)
""".replace('Path(TASK_ROOT)','Path('+repr(str(t))+')').replace('Path(BASELINE_ROOT)','Path('+repr(str(old))+')')
ast.parse(screen);(t/'screen_prefill.py').write_bytes(screen.encode())
rows.append(dict(path='screen_prefill.py',sha256=hashlib.sha256(screen.encode()).hexdigest()))
for name in ['vllm-ascend-bf16','dataset']:
 assert (old/name).is_dir();(t/name).symlink_to(old/name,target_is_directory=True)
for name in ['cpu_tests.rc','model_ready.json','source_manifest.json']:
 raw=(old/name).read_bytes();(t/name).write_bytes(raw)
 rows.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),baseline_copy=True))
(t/'helper_manifest.json').write_text(json.dumps(rows,indent=2))
ids=json.loads(subprocess.check_output(['docker','inspect','mm_bf16_serve_20260907','mm_bf16_ais_20260907'],universal_newlines=True))
(t/'baseline_manifest.json').write_text(json.dumps(dict(runtime=[dict(name=x['Name'],id=x['Id'],image=x['Image']) for x in ids],source=str(old/'vllm-ascend-bf16'),vllm_ascend_commit='44abd7d1c06e1c2c642f03101db295654aceabef',kernel_commit='e204056851f94a8b60b386eaa7689a0b1f3381ba',kernel_package=str(r/'package_v3'),model='/data2/weights/Qwen3.6-35B-A3B',devices=[0,5],ports=[8077,29541],hccl_env_mib=200,mc2_group_mib=206,rounds=['on_F1','off_E1','off_E2','on_F2'],launch='bash serve_bf16_v2.sh MODE ARM',serve_script_sha256=hashlib.sha256((t/'serve_bf16_v2.sh').read_bytes()).hexdigest()),indent=2))
(t/'measurement_scope.json').write_text(json.dumps(dict(mode='controlled_prefill_only',input_tokens=4096,output_tokens=1,concurrency=1,warmup=4,samples=12,order=['on_F1','off_E1','off_E2','on_F2'],long_AISBench_run=False),indent=2))
print('MODEL_HELPERS_STAGED_WITH_BASELINE_MANIFEST',str(t))
PY
