#!/usr/bin/env bash
set -euo pipefail
root=/data1/megamoe_gain_20260905/bf16_opt_20260907
base=/data1/megamoe_gain_20260905/bf16_20260907/ep2_qwen36_gmmfix
vendor=$1
mode=$2
label=$3
case "$vendor" in
 baseline) vend=/data1/megamoe_gain_20260905/package_v4/packages/vendors/mmgainv4_transformer ;;
 v1) vend=$root/package_v1/packages/vendors/mmbf16v1_transformer ;;
 v3) vend=$root/package_v3/packages/vendors/mmbf16v3_transformer ;;
 *) exit 11 ;;
esac
case "$mode" in record|compare|perf) ;; *) exit 12 ;; esac
[[ "$label" =~ ^[A-Za-z0-9_]+$ ]]
exec 9>/var/lock/megamoe_q36.lock
flock -n 9
out=$root/results/$label
test ! -e "$out"
mkdir -p "$out"
exec > "$out/run.log" 2>&1
on_exit() {
 rc=$?
 printf '%s\n' "$rc" > "$out/run.rc"
 python3 "$base/preflight_devices.py" > "$out/postflight.log" 2>&1
 printf '%s\n' "$?" > "$out/postflight.rc"
}
trap on_exit EXIT
printf '%s\n' "$$" > "$out/launcher.pid"
cat /proc/$$/stat > "$out/launcher.stat"
python3 "$base/preflight_devices.py"
if [[ "$mode" = perf ]]; then
 test "$(cat "$root/results/baseline_bf16_reference/run.rc")" = 0
 test "$(cat "$root/results/v3_correctness/run.rc")" = 0
fi
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,5
export ASCEND_CUSTOM_OPP_PATH="$vend:$base/vllm-ascend-bf16/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
export LD_LIBRARY_PATH="$vend/op_api/lib:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$base/vllm-ascend-bf16:/data1/megamoe_gain_20260905/source/torch_extension:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=/data1/megamoe_gain_20260905/torch_extensions
export MMGAIN_EXPECTED_VENDOR="$vend"
export MAX_JOBS=8 OMP_NUM_THREADS=1 TASK_QUEUE_ENABLE=1
export HCCL_DETERMINISTIC=true HCCL_OP_EXPANSION_MODE=AIV HCCL_BUFFSIZE=200
export HCCL_CONNECT_TIMEOUT=120 HCCL_EXEC_TIMEOUT=120
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export ASCEND_SLOG_PRINT_TO_STDOUT=0
if [[ "$mode" = perf ]]; then
 export ASCEND_GLOBAL_LOG_LEVEL=3
else
 export ASCEND_GLOBAL_LOG_LEVEL=0
 export ASCEND_PROCESS_LOG_PATH="$out/cann_logs"
 mkdir -p "$ASCEND_PROCESS_LOG_PATH"
fi
printf 'VENDOR %s MODE %s LABEL %s\n' "$vend" "$mode" "$label"
sha256sum "$vend/op_api/lib/libcust_opapi.so" "$root/bench_bf16.py"
timeout --signal=TERM --kill-after=25s 480s torchrun --nproc_per_node=2 --master_addr=127.0.0.1 --master_port=29541 "$root/bench_bf16.py" "$mode" "$out" "$root/results/baseline_bf16_reference"
printf '%s\n' RUN_COMPLETE
