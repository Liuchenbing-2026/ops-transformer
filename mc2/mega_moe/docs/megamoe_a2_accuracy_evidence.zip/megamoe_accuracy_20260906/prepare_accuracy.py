"""Prepare the recorded full GSM8K protocol in a new directory; never launch a service."""
import argparse
import hashlib
import json
import urllib.request
from pathlib import Path

DATA_URL = "https://raw.githubusercontent.com/openai/grade-school-math/3101c7d5072418e28b9008a6636bde82a006892c/grade_school_math/data/test.jsonl"
DATA_SHA = "3730d312f6e3440559ace48831e51066acaca737f6eabec99bccb9e4b3c39d14"
CONFIG_SHA = "de2a1e79d198eaa1729f9cd5884b843a281968a9fa40184e70c9cd3b87e2a353"
OLD_DATA = "/data1/megamoe_gain_20260905/accuracy_20260906/dataset"
OLD_MODEL = "/data1/Qwen3.6-35B-A3B-w8a8"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-config", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, help="Reuse a byte-identical official test.jsonl; otherwise download the pinned URL")
    args = parser.parse_args()
    assert args.work.is_absolute() and args.model.is_absolute()
    assert (args.model / "config.json").is_file() and not args.work.exists()
    config = args.source_config.read_bytes()
    assert hashlib.sha256(config).hexdigest() == CONFIG_SHA
    if args.dataset:
        data = args.dataset.read_bytes()
    else:
        with urllib.request.urlopen(DATA_URL, timeout=60) as response:
            data = response.read()
    assert hashlib.sha256(data).hexdigest() == DATA_SHA
    records = [json.loads(line) for line in data.splitlines() if line.strip()]
    assert len(records) == 1319 and all("question" in row and "####" in row["answer"] for row in records)
    text = config.decode("utf-8")
    assert text.count(OLD_DATA) == text.count(OLD_MODEL) == 1
    # Replace complete Python string literals so paths remain valid Python syntax.
    text = text.replace(repr(OLD_DATA), repr(str(args.work / "dataset"))).replace(repr(OLD_MODEL), repr(str(args.model)))
    assert "retry=1" in text and "ignore_eos=False" in text
    compile(text, "gsm8k_accuracy.py", "exec")
    args.work.mkdir(parents=True)
    dataset_dir = args.work / "dataset"
    dataset_dir.mkdir()
    (dataset_dir / "test.jsonl").write_bytes(data)
    (dataset_dir / "train.jsonl").write_bytes(b"")
    target = args.work / "gsm8k_accuracy.py"
    target.write_text(text, encoding="utf-8")
    (args.work / "preparation_manifest.json").write_text(json.dumps(dict(
        original_config_sha256=CONFIG_SHA, relocated_config_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
        source_url=DATA_URL, dataset_sha256=DATA_SHA, questions=len(records), model_path=str(args.model),
        path_changes_only=True), indent=2) + "\n", encoding="utf-8")
    print("PINNED_GSM8K_1319_AND_PATH_ONLY_CONFIG_READY", target)


if __name__ == "__main__":
    main()
