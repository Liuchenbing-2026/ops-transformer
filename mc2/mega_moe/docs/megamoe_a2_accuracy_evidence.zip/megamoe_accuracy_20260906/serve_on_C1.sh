#!/usr/bin/env bash
set -euo pipefail
root=/data1/megamoe_gain_20260905
python3 - "$root/results/vendor_order_E2_verified.json" "${1:-}" <<'PY_GATE'
from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);assert sys.argv[2] == 'v4', 'ONLY_VERIFIED_BASELINE_OR_V2'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='e7396b53c7bcc122fc04884b0f775f58aa935bd884dfd112c12e2cbe808f2477', 'RESOLUTION_MANIFEST_CHANGED'
m=json.loads(p.read_text());assert m['status']=='PASS'
for group in ('files','providers'):
 for name,sha in m[group].items():
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha, ('VERIFIED_INPUT_CHANGED',name)
print('VERIFIED_VENDOR_ORDER_E2_GATE_PASS_OLD_LAUNCHERS_STILL_LOCKED')
PY_GATE
test "$(cat "$root/results/dummy_cache_P3_cpu.rc")" = 0
python3 - <<'PY_DUMMY_GATE'
from pathlib import Path
import hashlib,json
r=Path('/data1/megamoe_gain_20260905');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=r/'results/dummy_cache_validated_source_manifest.json'
assert sha(p)=='80090cec4fea86b860947b3e49e61d99705bc11a26555d078cc4cddfe43330d1'
m=json.loads(p.read_text());assert m['cpu_tests_passed']==109 and m['npu_initialized'] is False
for row in m['files']:assert sha(r/'vllm-ascend-dummy_cache_P1'/row['source'])==row['sha256']
assert sha(r/'results/dummy_cache_P3_cpu.log')==m['cpu_log_sha256']
print('DUMMY_CACHE_VERIFIED_SOURCE_AND_109_CPU_TEST_GATE_PASS')
PY_DUMMY_GATE
python3 - <<'PY_V4_GATE'
from pathlib import Path
import hashlib,json
r=Path('/data1/megamoe_gain_20260905');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'results/ep8_perf_v4.rc').read_text().strip()=='0'
p=r/'results/v4_selected_kernel_verified.json';assert sha(p)=='ffc055844bc6aabdf2ed71e3654655b37658dd2578786968c374208369dce348'
selected=json.loads(p.read_text());assert selected['status']=='PASS' and sha(Path(selected['selected_kernel']))==selected['kernel_sha256']
correct=json.loads((r/'results/v4_checked_correctness_verified.json').read_text());assert correct['rank_cases']==40 and correct['status']=='PASS'
for row in correct['records']:assert sha(Path(row['path']))==row['sha256']
m=json.loads((r/'results/package_v4_manifest.json').read_text())
for row in m['files']:assert sha(r/'package_v4'/row['path'])==row['sha256']
perf=json.loads((r/'results/microbenchmark_v4_summary.json').read_text())
target=next(x for x in perf if x['label']=='t512_uniform')
assert target['both_v4_rounds_below_both_v2'] and target['reduction_pct']>5, 'V4_MICRO_GAIN_REQUIRED'
print('V4_CORRECTNESS_SELECTION_AND_REPEATED_GAIN_GATE_PASS')
PY_V4_GATE
test "${2:-}" = accuracy_final_on_C1
mode=$1;tag=$2
case "$mode" in
 baseline) mega=0;vend=/data1/ops_transformer_910/install92/vendors/optrans92_transformer ;;
 v1) mega=1;vend=$root/package_v1/packages/vendors/mmgainv1_transformer ;;
 v2) mega=1;vend=$root/package_v2/packages/vendors/mmgainv2_transformer ;;
 v4) mega=1;vend=$root/package_v4/packages/vendors/mmgainv4_transformer ;;
 *) exit 10 ;;
esac
[[ "$tag" =~ ^[a-zA-Z0-9_]+$ ]] || exit 11
out=$root/results/$tag
test ! -e "$out";mkdir "$out"
exec > "$out/server.log" 2>&1
printf '%s\n' "$$" > "$out/server.pid"
cat /proc/$$/stat > "$out/server.initial_stat"
npu-smi info > "$out/devices_before.txt"
python3 - "$out/devices_before.txt" <<'PY'
from pathlib import Path
import re,socket,sys
s=Path(sys.argv[1]).read_text();m=[int(x) for x in re.findall(r'(\d+)\s*/\s*65536',s)]
assert len(m)==8 and all(x<6000 for x in m),('DEVICE_BUSY',m)
assert all(f'No running processes found in NPU {i}' in s for i in range(8))
for port in (8077,29541):
 with socket.socket() as q:
  q.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);q.bind(('0.0.0.0',port))
print('MODEL_DEVICE_PORT_GATE_PASS',m)
PY
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
export ASCEND_CUSTOM_OPP_PATH="$vend:$root/vllm-ascend-dummy_cache_P1/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
export LD_LIBRARY_PATH=$vend/op_api/lib:${LD_LIBRARY_PATH:-}
export PYTHONPATH=$root/vllm-ascend-dummy_cache_P1:$root/source/torch_extension:${PYTHONPATH:-}
export TORCH_EXTENSIONS_DIR=$root/torch_extensions
export MAX_JOBS=8
export VLLM_CACHE_ROOT=$root/vllm_cache
export MEGAMOE=1
export MEGAMOE_SKIP_COMPILED=0
export HCCL_DETERMINISTIC=true
export SHARED_EXPERT_OVERLAP=0
export PORT=8077
export MODEL_PATH=/data1/Qwen3.6-35B-A3B-w8a8
export PREFIX_CACHING=0
printf 'MODEL_TEST_MODE %s VENDOR %s SOURCE %s\n' "$mode" "$vend" "$root/vllm-ascend-dummy_cache_P1"
sha256sum "$vend/op_api/lib/libcust_opapi.so" "$MODEL_PATH/config.json"
exec bash "$root/vllm-ascend-dummy_cache_P1/examples/online_serving/serve_qwen36_35b_a3b_w8a8_megamoe_a2.sh"
