"""Verify complete AISBench A/B evidence and summarize paired GSM8K scores offline."""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_arm(work, expected):
    predictions = list(work.glob("*/predictions/megamoe-final-accuracy/gsm8k.jsonl"))
    results = list(work.glob("*/results/megamoe-final-accuracy/gsm8k.json"))
    assert len(predictions) == len(results) == 1, "Ambiguous or missing AISBench outputs"
    rows = [json.loads(line) for line in predictions[0].read_text(encoding="utf-8").splitlines() if line.strip()]
    assert len(rows) == expected
    by_id = {row["id"]: row for row in rows}
    assert set(by_id) == set(range(expected))
    assert all(row.get("success") is True and isinstance(row.get("prediction"), str)
               and row["prediction"].strip() for row in rows)
    for failed in work.glob("*/predictions/**/*failed.jsonl"):
        assert not failed.read_text(encoding="utf-8").strip(), str(failed)
    result = json.loads(results[0].read_text(encoding="utf-8"))
    details = result["details"]
    assert isinstance(details, dict) and set(details) == {str(i) for i in range(expected)}
    assert all(isinstance(row["correct"], list) and len(row["correct"]) == 1
               and isinstance(row["correct"][0], bool) for row in details.values())
    correct = sum(row["correct"][0] for row in details.values())
    assert abs(result["accuracy"] - 100 * correct / expected) < 1e-8
    return by_id, details, dict(
        total=expected, successful=len(rows), correct=correct,
        accuracy=result["accuracy"], prediction_sha256=sha(predictions[0]), result_sha256=sha(results[0]))


def counters(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("vllm:request_success_total{"):
            continue
        labels = dict(re.findall(r'(\w+)="([^"]*)"', line))
        assert labels.get("model_name") == "qwen3.6-35b-a3b-w8a8"
        value = float(line.rsplit(" ", 1)[1])
        assert value.is_integer() and value >= 0
        reason = labels["finished_reason"]
        values[reason] = values.get(reason, 0) + int(value)
    assert values, "Missing vLLM finish counters"
    return values


def finish_delta(before, after, expected):
    a, b = counters(before), counters(after)
    delta = {key: b.get(key, 0) - a.get(key, 0) for key in sorted(set(a) | set(b))}
    assert all(value >= 0 for value in delta.values()), "Counters reset during evaluation"
    assert sum(delta.values()) == expected, ("Unexpected number of formal requests", delta)
    assert delta.get("error", 0) == delta.get("abort", 0) == 0
    return delta


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--off", type=Path, required=True)
    parser.add_argument("--on", type=Path, required=True)
    parser.add_argument("--metrics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected", type=int, default=1319)
    args = parser.parse_args()
    off_rows, off_details, off = read_arm(args.off, args.expected)
    on_rows, on_details, on = read_arm(args.on, args.expected)
    paired = dict(both_correct=0, both_wrong=0, on_only_correct=0, off_only_correct=0)
    rows = []
    for i in range(args.expected):
        a, b = off_rows[i], on_rows[i]
        da, db = off_details[str(i)], on_details[str(i)]
        assert a["gold"] == b["gold"] and a["origin_prompt"] == b["origin_prompt"], ("Input mismatch", i)
        assert da["references"] == db["references"], ("Reference mismatch", i)
        ac, bc = da["correct"][0], db["correct"][0]
        key = "both_correct" if ac and bc else "both_wrong" if not ac and not bc else "off_only_correct" if ac else "on_only_correct"
        paired[key] += 1
        rows.append(dict(
            id=i, reference=da["references"][0], off_answer=da["predictions"][0],
            on_answer=db["predictions"][0], off_correct=ac, on_correct=bc,
            extracted_answer_equal=da["predictions"] == db["predictions"],
            raw_output_equal=a["prediction"] == b["prediction"],
            off_output_sha256=hashlib.sha256(a["prediction"].encode()).hexdigest(),
            on_output_sha256=hashlib.sha256(b["prediction"].encode()).hexdigest()))
    for arm, name in [(off, args.off.name), (on, args.on.name)]:
        arm["finish_reasons"] = finish_delta(args.metrics / (name + "_metrics_before.txt"),
                                             args.metrics / (name + "_metrics_after.txt"), args.expected)
    summary = dict(
        status="COMPLETE_PAIRED_ACCURACY_EVIDENCE", primary_metric="accuracy",
        total=args.expected, off=off, on=on, difference_percentage_points=on["accuracy"] - off["accuracy"],
        paired=paired, extracted_answers_equal=sum(row["extracted_answer_equal"] for row in rows),
        raw_outputs_equal=sum(row["raw_output_equal"] for row in rows),
        scope="GSM8K full test under the recorded model, runtime, prompt, generation and concurrency settings; not a proof of universal or bitwise whole-model equivalence.")
    assert not args.output.exists(), "Do not overwrite a prior summary"
    args.output.mkdir(parents=True)
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with (args.output / "paired_questions.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
