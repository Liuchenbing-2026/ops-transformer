"""Require actual successful predictions and an AISBench accuracy result."""
from pathlib import Path
import hashlib
import json
import sys
from ais_bench.benchmark.datasets import Gsm8kEvaluator, gsm8k_dataset_postprocess, gsm8k_postprocess
from ais_bench.benchmark.utils.postprocess.model_postprocessors import extract_non_reasoning_content

work=Path(sys.argv[1]);expected=int(sys.argv[2])
pred_files=list(work.glob('*/predictions/megamoe-final-accuracy/gsm8k.jsonl'))
result_files=list(work.glob('*/results/megamoe-final-accuracy/gsm8k.json'))
assert len(pred_files)==len(result_files)==1,('MISSING_OR_AMBIGUOUS_RESULTS',pred_files,result_files)
rows=[json.loads(x) for x in pred_files[0].read_text().splitlines() if x.strip()]
assert len(rows)==expected and {x['id'] for x in rows}==set(range(expected))
assert all(x.get('success') is True and isinstance(x.get('prediction'),str) and x['prediction'].strip() for x in rows)
for p in work.glob('*/predictions/**/*failed.jsonl'):
    assert not p.read_text().strip(),('FAILED_PREDICTIONS',str(p))
result=json.loads(result_files[0].read_text());assert isinstance(result.get('accuracy'),(int,float))
details=result.get('details');assert isinstance(details,dict) and set(details)=={str(i) for i in range(expected)}
details=[details[str(i)] for i in range(expected)]
assert all(isinstance(x.get('correct'),list) and len(x['correct'])==1 and isinstance(x['correct'][0],bool) for x in details)
by_id={row['id']:row for row in rows}
scorer=Gsm8kEvaluator()
for i,detail in enumerate(details):
    row=by_id[i]
    prediction=gsm8k_postprocess(extract_non_reasoning_content(row['prediction']))
    reference=gsm8k_dataset_postprocess(row['gold'])
    assert detail['predictions']==[prediction] and detail['references']==[reference]
    assert detail['correct']==[scorer.is_equal(prediction,reference)]
correct=sum(x['correct'][0] for x in details)
assert abs(result['accuracy']-100*correct/expected)<1e-8
record=dict(status='PASS',total=expected,successful=len(rows),correct=correct,accuracy=result['accuracy'],
            primary_metric='accuracy',official_pipeline_recomputed=True,
            prediction_file=str(pred_files[0]),prediction_sha256=hashlib.sha256(pred_files[0].read_bytes()).hexdigest(),
            result_file=str(result_files[0]),result_sha256=hashlib.sha256(result_files[0].read_bytes()).hexdigest())
p=work/'verified_result.json';assert not p.exists();p.write_text(json.dumps(record,indent=2))
print('ACTUAL_AIS_ACCURACY_RESULT_VERIFIED',json.dumps(record),flush=True)
